# edge evidence: R1-m16-k128-f16-contig-t / default

verdict: **fused**

fusion decision stage: **scheduler** (scheduler considered 2 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/R1-m16-k128-f16-contig-t/default/output_code.py`
sha256: `068a5918e9c08261b34ec6a1483728303e3ed410368d8893e1b07dcfcb149027`

## kernels in launch order
0. `triton_per_fused_relu_sum_0`

## kernels containing both sides of the edge
- `triton_per_fused_relu_sum_0` aten=['aten.sum', 'aten.relu'] grid=grid(16) reads=['buf0', 'arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_per_fused_relu_sum_0` | {'XBLOCK': 1} | 13 | 0 | 8 | 2 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (16,) dtype torch.float32
- repeat-call bitwise equal: True
- default verdict: fused
