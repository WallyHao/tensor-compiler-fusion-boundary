class <lambda>(torch.nn.Module):
    def forward(self, arg0_1: "f16[16, 128]"):
         # File: /root/autodl-tmp/fusionh800-transfer/repo/src/fusionboundary/templates.py:38 in r1, code: t = torch.sum(x, dim=1, dtype=torch.float32)   # producer (t is always fp32)
        sum_1: "f32[16]" = torch.ops.aten.sum.dim_IntList(arg0_1, [1], dtype = torch.float32);  arg0_1 = None
        
         # File: /root/autodl-tmp/fusionh800-transfer/repo/src/fusionboundary/templates.py:39 in r1, code: return torch.relu(t)                            # consumer
        relu: "f32[16]" = torch.ops.aten.relu.default(sum_1);  sum_1 = None
        return (relu,)
        