# edge evidence: R2-m4096-k8192-f32-contig-t / fused

verdict: **fused**

fusion decision stage: **scheduler** (scheduler considered 2 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/R2-m4096-k8192-f32-contig-t/fused/output_code.py`
sha256: `10073bf09ba927c36db03bfbeed2fcd186a2c9ef242f9b689a50f1665758b408`

## kernels in launch order
0. `triton_red_fused_add_amax_mul_0`

## kernels containing both sides of the edge
- `triton_red_fused_add_amax_mul_0` aten=['aten.amax', 'aten.mul', 'aten.add'] grid=grid(4096) reads=['buf0', 'arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_red_fused_add_amax_mul_0` | {'XBLOCK': 1, 'RBLOCK': 2048} | 25 | 0 | 64 | 16 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (4096,) dtype torch.float32
- repeat-call bitwise equal: True
