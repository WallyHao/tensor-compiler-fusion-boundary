# edge evidence: R2-m4096-k8192-f32-contig-t / default

verdict: **fused**

fusion decision stage: **scheduler** (scheduler considered 2 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/R2-m4096-k8192-f32-contig-t/default/output_code.py`
sha256: `8f2734103932ec10062bb6dfdcb4b4e35e045fc9fd40d0706f763cb685fa746f`

## kernels in launch order
0. `triton_red_fused_add_amax_mul_0`

## kernels containing both sides of the edge
- `triton_red_fused_add_amax_mul_0` aten=['aten.amax', 'aten.mul', 'aten.add'] grid=grid(4096) reads=['buf0', 'arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_red_fused_add_amax_mul_0` | {'XBLOCK': 1, 'RBLOCK': 2048} | 25 | 0 | 64 | 16 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (4096,) dtype torch.float32
- repeat-call bitwise equal: True
- default verdict: fused
