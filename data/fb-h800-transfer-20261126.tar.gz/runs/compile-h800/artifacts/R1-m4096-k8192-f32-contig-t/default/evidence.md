# edge evidence: R1-m4096-k8192-f32-contig-t / default

verdict: **fused**

fusion decision stage: **scheduler** (scheduler considered 2 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/R1-m4096-k8192-f32-contig-t/default/output_code.py`
sha256: `27b10955daab72db5e4dddd2338797bc877b0686a70c8cc189156779d3edf297`

## kernels in launch order
0. `triton_red_fused_relu_sum_0`

## kernels containing both sides of the edge
- `triton_red_fused_relu_sum_0` aten=['aten.sum', 'aten.relu'] grid=grid(4096) reads=['buf0', 'arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_red_fused_relu_sum_0` | {'XBLOCK': 1, 'RBLOCK': 2048} | 27 | 0 | 64 | 16 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (4096,) dtype torch.float32
- repeat-call bitwise equal: True
- default verdict: fused
