class <lambda>(torch.nn.Module):
    def forward(self, arg0_1: "f16[524288]"):
         # File: /root/autodl-tmp/fusionh800-transfer/repo/src/fusionboundary/templates.py:33 in p2, code: t = torch.tanh(x)             # producer
        tanh: "f16[524288]" = torch.ops.aten.tanh.default(arg0_1);  arg0_1 = None
        
         # File: /root/autodl-tmp/fusionh800-transfer/repo/src/fusionboundary/templates.py:34 in p2, code: return t * P2_A + P2_B        # consumer
        mul: "f16[524288]" = torch.ops.aten.mul.Tensor(tanh, 0.75);  tanh = None
        add: "f16[524288]" = torch.ops.aten.add.Tensor(mul, 0.25);  mul = None
        return (add,)
        