# edge evidence: P2-n524288-f16-contig-t / default

verdict: **fused**

fusion decision stage: **lowering** (scheduler considered 0 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/P2-n524288-f16-contig-t/default/output_code.py`
sha256: `c4b0cb2e2c7762ee499afee0c4645116be5bb4145c67fa9cf8eed25a1eb3f6e7`

## kernels in launch order
0. `triton_poi_fused_add_mul_tanh_0`

## kernels containing both sides of the edge
- `triton_poi_fused_add_mul_tanh_0` aten=['aten.tanh', 'aten.mul', 'aten.add'] grid=grid(524288) reads=['arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_poi_fused_add_mul_tanh_0` | {'XBLOCK': 1024} | 19 | 0 | 0 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (524288,) dtype torch.float16
- repeat-call bitwise equal: True
- default verdict: fused
