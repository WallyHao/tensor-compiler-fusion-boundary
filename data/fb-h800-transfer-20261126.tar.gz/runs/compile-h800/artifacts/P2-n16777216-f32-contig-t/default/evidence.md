# edge evidence: P2-n16777216-f32-contig-t / default

verdict: **fused**

fusion decision stage: **lowering** (scheduler considered 0 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/P2-n16777216-f32-contig-t/default/output_code.py`
sha256: `1d7832f3531497c6aaac08596d326c4d34cb3e9358fda3092d6cb8d59da05e79`

## kernels in launch order
0. `triton_poi_fused_add_mul_tanh_0`

## kernels containing both sides of the edge
- `triton_poi_fused_add_mul_tanh_0` aten=['aten.tanh', 'aten.mul', 'aten.add'] grid=grid(16777216) reads=['arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_poi_fused_add_mul_tanh_0` | {'XBLOCK': 1024} | 19 | 0 | 0 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (16777216,) dtype torch.float32
- repeat-call bitwise equal: True
- default verdict: fused
