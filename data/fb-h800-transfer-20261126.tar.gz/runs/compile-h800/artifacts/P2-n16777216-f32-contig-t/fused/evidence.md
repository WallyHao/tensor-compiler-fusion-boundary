# edge evidence: P2-n16777216-f32-contig-t / fused

verdict: **fused**

fusion decision stage: **lowering** (scheduler considered 0 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/P2-n16777216-f32-contig-t/fused/output_code.py`
sha256: `03795c1dfaa617c14d714b7312bed80133d7bdb0691fd2cedf5d78a9dca5d724`

## kernels in launch order
0. `triton_poi_fused_add_mul_tanh_0`

## kernels containing both sides of the edge
- `triton_poi_fused_add_mul_tanh_0` aten=['aten.tanh', 'aten.mul', 'aten.add'] grid=grid(16777216) reads=['arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_poi_fused_add_mul_tanh_0` | {'XBLOCK': 1024} | 19 | 0 | 0 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (16777216,) dtype torch.float32
- repeat-call bitwise equal: True
