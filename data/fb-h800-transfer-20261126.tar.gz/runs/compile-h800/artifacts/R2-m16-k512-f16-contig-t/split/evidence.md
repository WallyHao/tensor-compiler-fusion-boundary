# edge evidence: R2-m16-k512-f16-contig-t / split

verdict: **materialized**

fusion decision stage: **not_fused** (scheduler considered 1 pair(s), 2 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/R2-m16-k512-f16-contig-t/split/output_code.py`
sha256: `c0ec19912b873a35746fa65423687a829da2ea9a950f3d0bcca6c8899317c98d`

## kernels in launch order
0. `triton_per_fused_amax_0`
1. `triton_poi_fused_add_mul_1`

## t write -> read
- buffer `buf0` shape=(16,) dtype=float16
  - written by `triton_per_fused_amax_0` (source nodes ['t'])
    - L35: `tl.store(out_ptr0 + (x0), tmp3, None)`
  - read by `triton_poi_fused_add_mul_1` (source nodes ['mul', 'add'])
    - L25: `tmp0 = tl.load(in_out_ptr0 + (x0), xmask).to(tl.float32)`
  - wrapper L139: `triton_per_fused_amax_0.run(arg0_1, buf0, 16, 512, grid=grid(16), stream=stream0)`
  - wrapper L144: `triton_poi_fused_add_mul_1.run(buf1, 16, grid=grid(16), stream=stream0)`
  - the consumer reads and writes the same buffer: the allocator handed t's storage to the output (in-place reuse)
  - reuse L141: `buf1 = buf0; del buf0  # reuse`

## lowering realize request
- fx node `amax` (aten.amax.default) -> buffer `buf0` status=`realized`

## fusion veto log
- gate `can_fuse_vertical` blocked: ['op0', 'buf0'] -> ['op1', 'buf1']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_per_fused_amax_0` | None | 12 | 0 | 16 | 4 | 1 |
| `triton_poi_fused_add_mul_1` | {'XBLOCK': 16} | 8 | 0 | 0 | 1 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (16,) dtype torch.float16
- repeat-call bitwise equal: True
- lowering realize: amax->buf0[realized]
- fusion gate ['torch._inductor.scheduler.Scheduler.can_fuse_vertical'] calls=1 blocks=1
