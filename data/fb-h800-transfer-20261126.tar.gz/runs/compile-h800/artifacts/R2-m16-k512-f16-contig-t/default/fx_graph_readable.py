class <lambda>(torch.nn.Module):
    def forward(self, arg0_1: "f16[16, 512]"):
         # File: /root/autodl-tmp/fusionh800-transfer/repo/src/fusionboundary/templates.py:43 in r2, code: t = torch.amax(x, dim=1)      # producer (t keeps input dtype)
        amax: "f16[16]" = torch.ops.aten.amax.default(arg0_1, [1]);  arg0_1 = None
        
         # File: /root/autodl-tmp/fusionh800-transfer/repo/src/fusionboundary/templates.py:44 in r2, code: return t * R2_A + R2_B        # consumer
        mul: "f16[16]" = torch.ops.aten.mul.Tensor(amax, 0.75);  amax = None
        add: "f16[16]" = torch.ops.aten.add.Tensor(mul, 0.25);  mul = None
        return (add,)
        