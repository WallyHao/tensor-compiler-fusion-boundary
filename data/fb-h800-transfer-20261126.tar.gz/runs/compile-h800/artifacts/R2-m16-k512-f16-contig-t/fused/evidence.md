# edge evidence: R2-m16-k512-f16-contig-t / fused

verdict: **fused**

fusion decision stage: **scheduler** (scheduler considered 2 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/R2-m16-k512-f16-contig-t/fused/output_code.py`
sha256: `be09c6ff477c5c3e710fb4c92175143ef6bcb2d54d7e86bab167eb33af5b8c7d`

## kernels in launch order
0. `triton_per_fused_add_amax_mul_0`

## kernels containing both sides of the edge
- `triton_per_fused_add_amax_mul_0` aten=['aten.amax', 'aten.mul', 'aten.add'] grid=grid(16) reads=['buf0', 'arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_per_fused_add_amax_mul_0` | None | 12 | 0 | 16 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (16,) dtype torch.float16
- repeat-call bitwise equal: True
