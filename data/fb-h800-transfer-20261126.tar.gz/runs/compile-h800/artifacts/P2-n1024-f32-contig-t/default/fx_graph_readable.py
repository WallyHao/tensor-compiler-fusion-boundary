class <lambda>(torch.nn.Module):
    def forward(self, arg0_1: "f32[1024]"):
         # File: /root/autodl-tmp/fusionh800-transfer/repo/src/fusionboundary/templates.py:33 in p2, code: t = torch.tanh(x)             # producer
        tanh: "f32[1024]" = torch.ops.aten.tanh.default(arg0_1);  arg0_1 = None
        
         # File: /root/autodl-tmp/fusionh800-transfer/repo/src/fusionboundary/templates.py:34 in p2, code: return t * P2_A + P2_B        # consumer
        mul: "f32[1024]" = torch.ops.aten.mul.Tensor(tanh, 0.75);  tanh = None
        add: "f32[1024]" = torch.ops.aten.add.Tensor(mul, 0.25);  mul = None
        return (add,)
        