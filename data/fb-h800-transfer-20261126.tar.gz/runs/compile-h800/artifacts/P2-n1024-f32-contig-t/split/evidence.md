# edge evidence: P2-n1024-f32-contig-t / split

verdict: **materialized**

fusion decision stage: **not_fused** (scheduler considered 1 pair(s), 2 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/P2-n1024-f32-contig-t/split/output_code.py`
sha256: `c07feb830b76203daacbda606835c2c7c5312accf69f61316aad1d0300f0c3e7`

## kernels in launch order
0. `triton_poi_fused_tanh_0`
1. `triton_poi_fused_add_mul_1`

## t write -> read
- buffer `buf0` shape=(1024,) dtype=float32
  - written by `triton_poi_fused_tanh_0` (source nodes ['t'])
    - L27: `tl.store(out_ptr0 + (x0), tmp1, xmask)`
  - read by `triton_poi_fused_add_mul_1` (source nodes ['mul', 'add'])
    - L25: `tmp0 = tl.load(in_out_ptr0 + (x0), xmask)`
  - wrapper L131: `triton_poi_fused_tanh_0.run(arg0_1, buf0, 1024, grid=grid(1024), stream=stream0)`
  - wrapper L136: `triton_poi_fused_add_mul_1.run(buf1, 1024, grid=grid(1024), stream=stream0)`
  - the consumer reads and writes the same buffer: the allocator handed t's storage to the output (in-place reuse)
  - reuse L133: `buf1 = buf0; del buf0  # reuse`

## lowering realize request
- fx node `tanh` (aten.tanh.default) -> buffer `buf0` status=`realized`

## fusion veto log
- gate `can_fuse_vertical` blocked: ['op0', 'buf0'] -> ['op1', 'buf1']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_poi_fused_tanh_0` | {'XBLOCK': 256} | 11 | 0 | 0 | 4 | 1 |
| `triton_poi_fused_add_mul_1` | {'XBLOCK': 256} | 8 | 0 | 0 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (1024,) dtype torch.float32
- repeat-call bitwise equal: True
- lowering realize: tanh->buf0[realized]
- fusion gate ['torch._inductor.scheduler.Scheduler.can_fuse_vertical'] calls=1 blocks=1
