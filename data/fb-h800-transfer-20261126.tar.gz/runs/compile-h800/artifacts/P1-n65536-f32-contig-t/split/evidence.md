# edge evidence: P1-n65536-f32-contig-t / split

verdict: **materialized**

fusion decision stage: **not_fused** (scheduler considered 1 pair(s), 2 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/P1-n65536-f32-contig-t/split/output_code.py`
sha256: `1eee628936464f8756aa51812b831d916a28e9b12471698343c296a6f11c00df`

## kernels in launch order
0. `triton_poi_fused_add_mul_0`
1. `triton_poi_fused_relu_1`

## t write -> read
- buffer `buf0` shape=(65536,) dtype=float32
  - written by `triton_poi_fused_add_mul_0` (source nodes ['mul', 't'])
    - L30: `tl.store(out_ptr0 + (x0), tmp4, None)`
  - read by `triton_poi_fused_relu_1` (source nodes ['relu'])
    - L25: `tmp0 = tl.load(in_out_ptr0 + (x0), None)`
  - wrapper L132: `triton_poi_fused_add_mul_0.run(arg0_1, buf0, 65536, grid=grid(65536), stream=stream0)`
  - wrapper L137: `triton_poi_fused_relu_1.run(buf1, 65536, grid=grid(65536), stream=stream0)`
  - the consumer reads and writes the same buffer: the allocator handed t's storage to the output (in-place reuse)
  - reuse L134: `buf1 = buf0; del buf0  # reuse`

## lowering realize request
- fx node `add` (aten.add.Tensor) -> buffer `buf0` status=`realized`

## fusion veto log
- gate `can_fuse_vertical` blocked: ['op0', 'buf0'] -> ['op1', 'buf1']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_poi_fused_add_mul_0` | {'XBLOCK': 512} | 14 | 0 | 0 | 4 | 1 |
| `triton_poi_fused_relu_1` | {'XBLOCK': 512} | 10 | 0 | 0 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (65536,) dtype torch.float32
- repeat-call bitwise equal: True
- lowering realize: add->buf0[realized]
- fusion gate ['torch._inductor.scheduler.Scheduler.can_fuse_vertical'] calls=1 blocks=1
