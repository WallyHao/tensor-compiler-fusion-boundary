# edge evidence: R1-m256-k512-f32-contig-t / default

verdict: **fused**

fusion decision stage: **scheduler** (scheduler considered 2 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/R1-m256-k512-f32-contig-t/default/output_code.py`
sha256: `08d84010d136b6cf842d8b8db865dcf31a6ff6a37f7c352abea2dca5024dd14d`

## kernels in launch order
0. `triton_per_fused_relu_sum_0`

## kernels containing both sides of the edge
- `triton_per_fused_relu_sum_0` aten=['aten.sum', 'aten.relu'] grid=grid(256) reads=['buf0', 'arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_per_fused_relu_sum_0` | None | 14 | 0 | 16 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (256,) dtype torch.float32
- repeat-call bitwise equal: True
- default verdict: fused
