# edge evidence: R1-m256-k512-f32-contig-t / fused

verdict: **fused**

fusion decision stage: **scheduler** (scheduler considered 2 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusionh800-transfer/runs/compile-h800/artifacts/R1-m256-k512-f32-contig-t/fused/output_code.py`
sha256: `d36872c1db99d3947827df5b0ad7b3092c87db7ee0d6715ab29f257342d7aeab`

## kernels in launch order
0. `triton_per_fused_relu_sum_0`

## kernels containing both sides of the edge
- `triton_per_fused_relu_sum_0` aten=['aten.sum', 'aten.relu'] grid=grid(256) reads=['buf0', 'arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_per_fused_relu_sum_0` | None | 14 | 0 | 16 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (256,) dtype torch.float32
- repeat-call bitwise equal: True
