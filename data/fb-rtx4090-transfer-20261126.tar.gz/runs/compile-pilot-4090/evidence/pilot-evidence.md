# Pilot evidence · run `compile-pilot-4090`

generated 2026-11-26T05:52:07Z by `/root/autodl-tmp/fusion4090-20261126/repo/src/fusionboundary/__main__.py`

## P1-n65536-f32-contig-t

- template `P1` shape=[65536] dtype=float32 t=([65536],float32) logical_save_bytes=524288
- tolerance atol=1e-06 rtol=1e-05

- **default**: status=`valid` kernels=1 t_materialized=False verdict=`fused` checks_failed=0 graph_breaks=0 default_maps_to=fused
- **fused**: status=`valid` kernels=1 t_materialized=False verdict=`fused` checks_failed=0 graph_breaks=0 default_maps_to=None
- **split**: status=`valid` kernels=2 t_materialized=True verdict=`materialized` checks_failed=0 graph_breaks=0 default_maps_to=None

```json
{
  "default_maps_to": "fused",
  "kernel_count_fused": 1,
  "kernel_count_split": 2,
  "partition_equal_default_fused": true,
  "partition_equal_default_split": false,
  "partitions_identical_split_fused": false,
  "same_op_set_split_fused": true,
  "shared_kernel_count": 0,
  "unrelated_partition_change": false
}
```

### default · generated-code evidence

# edge evidence: P1-n65536-f32-contig-t / default

verdict: **fused**

fusion decision stage: **lowering** (scheduler considered 0 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusion4090-20261126/runs/compile-pilot-4090/artifacts/P1-n65536-f32-contig-t/default/output_code.py`
sha256: `51b394b3836bf2db9b056c3995ab55227d4bf0cff3d240d97596f1115d7761f2`

## kernels in launch order
0. `triton_poi_fused_add_mul_relu_0`

## kernels containing both sides of the edge
- `triton_poi_fused_add_mul_relu_0` aten=['aten.mul', 'aten.add', 'aten.relu'] grid=grid(65536) reads=['arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_poi_fused_add_mul_relu_0` | {'XBLOCK': 512} | 14 | 0 | 0 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (65536,) dtype torch.float32
- repeat-call bitwise equal: True
- default verdict: fused


### fused · generated-code evidence

# edge evidence: P1-n65536-f32-contig-t / fused

verdict: **fused**

fusion decision stage: **lowering** (scheduler considered 0 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusion4090-20261126/runs/compile-pilot-4090/artifacts/P1-n65536-f32-contig-t/fused/output_code.py`
sha256: `a9a9d1adca28a46a6cf6d4d6dcd5663518655c8b5fca98da04b28b28da6dadcb`

## kernels in launch order
0. `triton_poi_fused_add_mul_relu_0`

## kernels containing both sides of the edge
- `triton_poi_fused_add_mul_relu_0` aten=['aten.mul', 'aten.add', 'aten.relu'] grid=grid(65536) reads=['arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_poi_fused_add_mul_relu_0` | {'XBLOCK': 512} | 14 | 0 | 0 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (65536,) dtype torch.float32
- repeat-call bitwise equal: True


### split · generated-code evidence

# edge evidence: P1-n65536-f32-contig-t / split

verdict: **materialized**

fusion decision stage: **not_fused** (scheduler considered 1 pair(s), 2 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusion4090-20261126/runs/compile-pilot-4090/artifacts/P1-n65536-f32-contig-t/split/output_code.py`
sha256: `968e9ea5f8bcc9ed16f897bd8bb01b2c0d6c907ab6af8e5652f703baaa6ba4f9`

## kernels in launch order
0. `triton_poi_fused_add_mul_0`
1. `triton_poi_fused_relu_1`

## t write -> read
- buffer `buf0` shape=(65536,) dtype=float32
  - written by `triton_poi_fused_add_mul_0` (source nodes ['mul', 't'])
    - L30: `tl.store(out_ptr0 + (x0), tmp4, None)`
  - read by `triton_poi_fused_relu_1` (source nodes ['relu'])
    - L25: `tmp0 = tl.load(in_out_ptr0 + (x0), None)`
  - wrapper L132: `triton_poi_fused_add_mul_0.run(arg0_1, buf0, 65536, grid=grid(65536), stream=stream0)`
  - wrapper L137: `triton_poi_fused_relu_1.run(buf1, 65536, grid=grid(65536), stream=stream0)`
  - the consumer reads and writes the same buffer: the allocator handed t's storage to the output (in-place reuse)
  - reuse L134: `buf1 = buf0; del buf0  # reuse`

## lowering realize request
- fx node `add` (aten.add.Tensor) -> buffer `buf0` status=`realized`

## fusion veto log
- gate `can_fuse_vertical` blocked: ['op0', 'buf0'] -> ['op1', 'buf1']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_poi_fused_add_mul_0` | {'XBLOCK': 512} | 16 | 0 | 0 | 4 | 1 |
| `triton_poi_fused_relu_1` | {'XBLOCK': 512} | 10 | 0 | 0 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (65536,) dtype torch.float32
- repeat-call bitwise equal: True
- lowering realize: add->buf0[realized]
- fusion gate ['torch._inductor.scheduler.Scheduler.can_fuse_vertical'] calls=1 blocks=1


### numerical checks

| strategy | input | pass | max_abs | max_rel | fp64 max_abs |
|---|---|---|---|---|---|
| default | seed17 | True | 0.000e+00 | 0.000e+00 | — |
| default | seed29 | True | 0.000e+00 | 0.000e+00 | — |
| default | seed43 | True | 0.000e+00 | 0.000e+00 | — |
| default | zeros | True | 0.000e+00 | 0.000e+00 | — |
| default | load_report | True | — | — | — |
| split | seed17 | True | 0.000e+00 | 0.000e+00 | — |
| split | seed29 | True | 0.000e+00 | 0.000e+00 | — |
| split | seed43 | True | 0.000e+00 | 0.000e+00 | — |
| split | zeros | True | 0.000e+00 | 0.000e+00 | — |
| split | load_report | True | — | — | — |
| fused | seed17 | True | 0.000e+00 | 0.000e+00 | — |
| fused | seed29 | True | 0.000e+00 | 0.000e+00 | — |
| fused | seed43 | True | 0.000e+00 | 0.000e+00 | — |
| fused | zeros | True | 0.000e+00 | 0.000e+00 | — |
| fused | load_report | True | — | — | — |

## R1-m256-k512-f32-contig-t

- template `R1` shape=[256, 512] dtype=float32 t=([256],float32) logical_save_bytes=2048
- tolerance atol=0.0002 rtol=0.0001

- **default**: status=`valid` kernels=1 t_materialized=False verdict=`fused` checks_failed=0 graph_breaks=0 default_maps_to=fused
- **fused**: status=`valid` kernels=1 t_materialized=False verdict=`fused` checks_failed=0 graph_breaks=0 default_maps_to=None
- **split**: status=`valid` kernels=2 t_materialized=True verdict=`materialized` checks_failed=0 graph_breaks=0 default_maps_to=None

```json
{
  "default_maps_to": "fused",
  "kernel_count_fused": 1,
  "kernel_count_split": 2,
  "partition_equal_default_fused": true,
  "partition_equal_default_split": false,
  "partitions_identical_split_fused": false,
  "same_op_set_split_fused": true,
  "shared_kernel_count": 0,
  "unrelated_partition_change": false
}
```

### default · generated-code evidence

# edge evidence: R1-m256-k512-f32-contig-t / default

verdict: **fused**

fusion decision stage: **scheduler** (scheduler considered 2 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusion4090-20261126/runs/compile-pilot-4090/artifacts/R1-m256-k512-f32-contig-t/default/output_code.py`
sha256: `492f6efab11653752d214e9416436b21873db66f837b7795547fcdb6b89f7e7a`

## kernels in launch order
0. `triton_per_fused_relu_sum_0`

## kernels containing both sides of the edge
- `triton_per_fused_relu_sum_0` aten=['aten.sum', 'aten.relu'] grid=grid(256) reads=['buf0', 'arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_per_fused_relu_sum_0` | None | 14 | 0 | 16 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (256,) dtype torch.float32
- repeat-call bitwise equal: True
- default verdict: fused


### fused · generated-code evidence

# edge evidence: R1-m256-k512-f32-contig-t / fused

verdict: **fused**

fusion decision stage: **scheduler** (scheduler considered 2 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusion4090-20261126/runs/compile-pilot-4090/artifacts/R1-m256-k512-f32-contig-t/fused/output_code.py`
sha256: `2041c75e80657e8a3532d64a555445324b93b954cb3ddbe12fff66dade7ec00f`

## kernels in launch order
0. `triton_per_fused_relu_sum_0`

## kernels containing both sides of the edge
- `triton_per_fused_relu_sum_0` aten=['aten.sum', 'aten.relu'] grid=grid(256) reads=['buf0', 'arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_per_fused_relu_sum_0` | None | 14 | 0 | 16 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (256,) dtype torch.float32
- repeat-call bitwise equal: True


### split · generated-code evidence

# edge evidence: R1-m256-k512-f32-contig-t / split

verdict: **materialized**

fusion decision stage: **not_fused** (scheduler considered 1 pair(s), 2 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusion4090-20261126/runs/compile-pilot-4090/artifacts/R1-m256-k512-f32-contig-t/split/output_code.py`
sha256: `c72c131623b699f53aa03ee9e470ee0d29b3e87bdb50034aaac5db7e7d13fa51`

## kernels in launch order
0. `triton_per_fused_sum_0`
1. `triton_poi_fused_relu_1`

## t write -> read
- buffer `buf0` shape=(256,) dtype=float32
  - written by `triton_per_fused_sum_0` (source nodes ['t'])
    - L35: `tl.store(out_ptr0 + (x0), tmp3, None)`
  - read by `triton_poi_fused_relu_1` (source nodes ['relu'])
    - L25: `tmp0 = tl.load(in_out_ptr0 + (x0), xmask)`
  - wrapper L135: `triton_per_fused_sum_0.run(arg0_1, buf0, 256, 512, grid=grid(256), stream=stream0)`
  - wrapper L140: `triton_poi_fused_relu_1.run(buf1, 256, grid=grid(256), stream=stream0)`
  - the consumer reads and writes the same buffer: the allocator handed t's storage to the output (in-place reuse)
  - reuse L137: `buf1 = buf0; del buf0  # reuse`

## lowering realize request
- fx node `sum_1` (aten.sum.dim_IntList) -> buffer `buf0` status=`realized`

## fusion veto log
- gate `can_fuse_vertical` blocked: ['op0', 'buf0'] -> ['op1', 'buf1']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_per_fused_sum_0` | None | 14 | 0 | 16 | 4 | 1 |
| `triton_poi_fused_relu_1` | {'XBLOCK': 256} | 8 | 0 | 0 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (256,) dtype torch.float32
- repeat-call bitwise equal: True
- lowering realize: sum_1->buf0[realized]
- fusion gate ['torch._inductor.scheduler.Scheduler.can_fuse_vertical'] calls=1 blocks=1


### numerical checks

| strategy | input | pass | max_abs | max_rel | fp64 max_abs |
|---|---|---|---|---|---|
| default | seed17 | True | 3.815e-06 | 2.960e-06 | 2.623e-06 |
| default | seed29 | True | 3.815e-06 | 1.143e-05 | 4.172e-06 |
| default | seed43 | True | 3.815e-06 | 1.135e-04 | 2.265e-06 |
| default | zeros | True | 0.000e+00 | 0.000e+00 | 0.000e+00 |
| default | load_report | True | — | — | — |
| split | seed17 | True | 3.815e-06 | 2.960e-06 | 2.623e-06 |
| split | seed29 | True | 3.815e-06 | 1.143e-05 | 4.172e-06 |
| split | seed43 | True | 3.815e-06 | 1.135e-04 | 2.265e-06 |
| split | zeros | True | 0.000e+00 | 0.000e+00 | 0.000e+00 |
| split | load_report | True | — | — | — |
| fused | seed17 | True | 3.815e-06 | 2.960e-06 | 2.623e-06 |
| fused | seed29 | True | 3.815e-06 | 1.143e-05 | 4.172e-06 |
| fused | seed43 | True | 3.815e-06 | 1.135e-04 | 2.265e-06 |
| fused | zeros | True | 0.000e+00 | 0.000e+00 | 0.000e+00 |
| fused | load_report | True | — | — | — |

