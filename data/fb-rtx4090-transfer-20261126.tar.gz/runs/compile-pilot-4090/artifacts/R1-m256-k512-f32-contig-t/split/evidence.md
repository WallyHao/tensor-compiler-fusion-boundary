# edge evidence: R1-m256-k512-f32-contig-t / split

verdict: **materialized**

fusion decision stage: **not_fused** (scheduler considered 1 pair(s), 2 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusion4090-20261126/runs/compile-pilot-4090/artifacts/R1-m256-k512-f32-contig-t/split/output_code.py`
sha256: `c72c131623b699f53aa03ee9e470ee0d29b3e87bdb50034aaac5db7e7d13fa51`

## kernels in launch order
0. `triton_per_fused_sum_0`
1. `triton_poi_fused_relu_1`

## t write -> read
- buffer `buf0` shape=(256,) dtype=float32
  - written by `triton_per_fused_sum_0` (source nodes ['t'])
    - L35: `tl.store(out_ptr0 + (x0), tmp3, None)`
  - read by `triton_poi_fused_relu_1` (source nodes ['relu'])
    - L25: `tmp0 = tl.load(in_out_ptr0 + (x0), xmask)`
  - wrapper L135: `triton_per_fused_sum_0.run(arg0_1, buf0, 256, 512, grid=grid(256), stream=stream0)`
  - wrapper L140: `triton_poi_fused_relu_1.run(buf1, 256, grid=grid(256), stream=stream0)`
  - the consumer reads and writes the same buffer: the allocator handed t's storage to the output (in-place reuse)
  - reuse L137: `buf1 = buf0; del buf0  # reuse`

## lowering realize request
- fx node `sum_1` (aten.sum.dim_IntList) -> buffer `buf0` status=`realized`

## fusion veto log
- gate `can_fuse_vertical` blocked: ['op0', 'buf0'] -> ['op1', 'buf1']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_per_fused_sum_0` | None | 14 | 0 | 16 | 4 | 1 |
| `triton_poi_fused_relu_1` | {'XBLOCK': 256} | 8 | 0 | 0 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (256,) dtype torch.float32
- repeat-call bitwise equal: True
- lowering realize: sum_1->buf0[realized]
- fusion gate ['torch._inductor.scheduler.Scheduler.can_fuse_vertical'] calls=1 blocks=1
