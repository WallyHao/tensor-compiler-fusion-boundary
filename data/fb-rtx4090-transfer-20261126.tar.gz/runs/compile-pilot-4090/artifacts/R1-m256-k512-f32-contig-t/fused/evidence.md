# edge evidence: R1-m256-k512-f32-contig-t / fused

verdict: **fused**

fusion decision stage: **scheduler** (scheduler considered 2 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusion4090-20261126/runs/compile-pilot-4090/artifacts/R1-m256-k512-f32-contig-t/fused/output_code.py`
sha256: `2041c75e80657e8a3532d64a555445324b93b954cb3ddbe12fff66dade7ec00f`

## kernels in launch order
0. `triton_per_fused_relu_sum_0`

## kernels containing both sides of the edge
- `triton_per_fused_relu_sum_0` aten=['aten.sum', 'aten.relu'] grid=grid(256) reads=['buf0', 'arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_per_fused_relu_sum_0` | None | 14 | 0 | 16 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (256,) dtype torch.float32
- repeat-call bitwise equal: True
