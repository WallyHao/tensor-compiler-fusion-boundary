# edge evidence: P1-n65536-f32-contig-t / default

verdict: **fused**

fusion decision stage: **lowering** (scheduler considered 0 pair(s), 1 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusion4090-20261126/runs/compile-corpus-4090/artifacts/P1-n65536-f32-contig-t/default/output_code.py`
sha256: `413fd657cb16a398de6e9cf678b3deb5bf3ce5759acae693597dbc2558fc6615`

## kernels in launch order
0. `triton_poi_fused_add_mul_relu_0`

## kernels containing both sides of the edge
- `triton_poi_fused_add_mul_relu_0` aten=['aten.mul', 'aten.add', 'aten.relu'] grid=grid(65536) reads=['arg0_1'] writes=['buf0']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_poi_fused_add_mul_relu_0` | {'XBLOCK': 512} | 14 | 0 | 0 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (65536,) dtype torch.float32
- repeat-call bitwise equal: True
- default verdict: fused
