# edge evidence: P1-n524288-f32-contig-t / split

verdict: **materialized**

fusion decision stage: **not_fused** (scheduler considered 1 pair(s), 2 kernel(s))

compiled graphs in trace: 1

output_code: `/root/autodl-tmp/fusion4090-20261126/runs/compile-corpus-4090/artifacts/P1-n524288-f32-contig-t/split/output_code.py`
sha256: `8340f0b0b34d0022319c0b55e7900d953153747beeedcffbacdcf8ad45c7177e`

## kernels in launch order
0. `triton_poi_fused_add_mul_0`
1. `triton_poi_fused_relu_1`

## t write -> read
- buffer `buf0` shape=(524288,) dtype=float32
  - written by `triton_poi_fused_add_mul_0` (source nodes ['mul', 't'])
    - L30: `tl.store(out_ptr0 + (x0), tmp4, None)`
  - read by `triton_poi_fused_relu_1` (source nodes ['relu'])
    - L25: `tmp0 = tl.load(in_out_ptr0 + (x0), None)`
  - wrapper L132: `triton_poi_fused_add_mul_0.run(arg0_1, buf0, 524288, grid=grid(524288), stream=stream0)`
  - wrapper L137: `triton_poi_fused_relu_1.run(buf1, 524288, grid=grid(524288), stream=stream0)`
  - the consumer reads and writes the same buffer: the allocator handed t's storage to the output (in-place reuse)
  - reuse L134: `buf1 = buf0; del buf0  # reuse`

## lowering realize request
- fx node `add` (aten.add.Tensor) -> buffer `buf0` status=`realized`

## fusion veto log
- gate `can_fuse_vertical` blocked: ['op0', 'buf0'] -> ['op1', 'buf1']

## static kernel resources (block / registers / shared / warps)

| kernel | block | regs | spills | shared B | warps | stages |
|---|---|---|---|---|---|---|
| `triton_poi_fused_add_mul_0` | {'XBLOCK': 1024} | 18 | 0 | 0 | 4 | 1 |
| `triton_poi_fused_relu_1` | {'XBLOCK': 1024} | 14 | 0 | 0 | 4 | 1 |

每个数值的来源属性记录在 `edge_evidence.json` 的 `kernel_resources[*].sources`。

## notes
- compile input: seed17
- output shape (524288,) dtype torch.float32
- repeat-call bitwise equal: True
- lowering realize: add->buf0[realized]
- fusion gate ['torch._inductor.scheduler.Scheduler.can_fuse_vertical'] calls=1 blocks=1
