class <lambda>(torch.nn.Module):
    def forward(self, arg0_1: "f32[1024]"):
         # File: /root/autodl-tmp/fusion4090-20261126/repo/src/fusionboundary/templates.py:28 in p1, code: t = x * P1_A + P1_B          # producer
        mul: "f32[1024]" = torch.ops.aten.mul.Tensor(arg0_1, 1.25);  arg0_1 = None
        add: "f32[1024]" = torch.ops.aten.add.Tensor(mul, 0.25);  mul = None
        
         # File: /root/autodl-tmp/fusion4090-20261126/repo/src/fusionboundary/templates.py:29 in p1, code: return torch.relu(t)          # consumer
        relu: "f32[1024]" = torch.ops.aten.relu.default(add);  add = None
        return (relu,)
        